﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using MySql.Data.MySqlClient;


namespace Warehouse_Control
{

    public partial class ItemID_list : Form
    {
        public Entities ef = new Entities();
        private string _connectionString;
 

        public ItemID_list()
        {
            InitializeComponent();
        }


        private void btn_StockReplishment_Click(object sender, EventArgs e)
        {

           

            try
            {

                //資料庫位址
                MySqlConnection myConnection = new MySqlConnection("server = remotemysql.com; user=0i34zb2JRd; database = 0i34zb2JRd; port = 3306; password = 1ygqpDmMJv;");


                //開啟資料庫
                myConnection.Open();
               


                //新增一筆資料
                MySqlCommand cmd = new MySqlCommand();
                cmd.Connection = myConnection;





                cmd.CommandText = "INSERT INTO item VALUES(@1,@2,@3,@4,@5,@6,@7,@8)";
                cmd.Parameters.AddWithValue("@1", txtStockReplishmentNewItemID.Text);
                cmd.Parameters.AddWithValue("@2", txtStockReplishmentNewItemName.Text);
                cmd.Parameters.AddWithValue("@3", txtStockReplishmentNewItemQuantity.Text);
                cmd.Parameters.AddWithValue("@4", txtStockReplishmentNewItemRemark.Text);
                cmd.Parameters.AddWithValue("@5", txtStockReplishmentNewItemStockRegion.Text);
                cmd.Parameters.AddWithValue("@6", txtStockReplishmentNewItemSparesCategory.Text);
                cmd.Parameters.AddWithValue("@7", txtStockReplishmentNewItemPrice.Text);
                cmd.Parameters.AddWithValue("@8", comStockReplishmentNewSupplierID.Text);

                cmd.ExecuteNonQuery();

                myConnection.Close();
                MessageBox.Show("Insert is successful");
            }
            catch
            {
                MessageBox.Show("Please ensure that the value is entered in corrent format");
            }  

            this.dataGridView1.DataSource = null;
            this.dataGridView1.Rows.Clear();


            using (var classicContext = new Entities())
            {

                var items = (from list in classicContext.item
                             select list);    // select * from employees

                foreach (var item1 in items.ToList())
                {
                    dataGridView1.Rows.Add(item1.ItemID, item1.ItemName, item1.Quantity, item1.Remarks, item1.StockRegion, item1.SparesCategory, item1.Price, item1.SupplierID);
                }

            }

        }


        private void ItemID_list_Load(object sender, EventArgs e)
        {
            this.dataGridView1.DataSource = null;
            this.dataGridView1.Rows.Clear();
            RadEditReorder.Checked = true;
           
            using (var classicContext = new Entities())
            {

                var items = (from list in classicContext.item
                             select list);    // select * from employees

                foreach (var item1 in items.ToList())
                {
                    dataGridView1.Rows.Add(item1.ItemID, item1.ItemName, item1.Quantity, item1.Remarks, item1.StockRegion, item1.SparesCategory, item1.Price, item1.SupplierID);
                }

            }

            using (var classicContext = new Entities())
            {

                var suppliers = (from list in classicContext.supplier
                                 select list);    // select * from employees

                foreach (var supplier1 in suppliers.ToList())
                {
                    comStockReplishmentNewSupplierID.Items.Add(supplier1.SupplierID);
                }

            }

            using (var classicContext = new Entities())
            {

                var items = (from list in classicContext.item
                             select list);    // select * from employees

                foreach (var item1 in items.ToList())
                {
                    comReorderItemID.Items.Add(item1.ItemID);
                }

            }


            comReorderStatus.Items.Add("CPT");
            comReorderStatus.Items.Add("DED");


            using (var classicContext = new Entities())
            {
                var items = (from list in classicContext.item
                             select list);    // select * from employees



                foreach (var item1 in items.ToList())
                {
                    comStockReplishmentExistingItemID.Items.Add(item1.ItemID);
                }
            }

            using (var classicContext = new Entities())
            {
                var reorders = (from list in classicContext.reorder
                                select list);    // select * from employees



                foreach (var reorder1 in reorders.ToList())
                {
                    dataGridView2.Rows.Add(reorder1.ReorderID, reorder1.Status, reorder1.TotalPrice, reorder1.Date, reorder1.itemID, reorder1.quantity);

                }
            }



        }

      



        private void RadEditReorder_CheckedChanged(object sender, EventArgs e)
        {
            txtReorderID.ReadOnly = false;
            txtReorderDate.ReadOnly = false;
            comReorderStatus.Enabled = true;
            comReorderItemID.Enabled = true;
            txtReorderTotalPrice.ReadOnly = false;
            txtReorderQuantity.ReadOnly = false;



            txtStockReplishmentNewItemID.ReadOnly = true;
            txtStockReplishmentNewItemName.ReadOnly = true;
            txtStockReplishmentNewItemQuantity.ReadOnly = true;
            txtStockReplishmentNewItemRemark.ReadOnly = true;
            txtStockReplishmentNewItemStockRegion.ReadOnly = true;
            txtStockReplishmentNewItemSparesCategory.ReadOnly = true;
            txtStockReplishmentNewItemPrice.ReadOnly = true;
            comStockReplishmentNewSupplierID.Enabled = false;


            txtStockReplishmentExistingItemQuantity.ReadOnly = true;
            comStockReplishmentExistingItemID.Enabled = false;
        }

        private void RadEditNewItem_CheckedChanged(object sender, EventArgs e)
        {
            txtStockReplishmentNewItemID.ReadOnly = false;
            txtStockReplishmentNewItemName.ReadOnly = false;
            txtStockReplishmentNewItemQuantity.ReadOnly = false;
            txtStockReplishmentNewItemRemark.ReadOnly = false;
            txtStockReplishmentNewItemStockRegion.ReadOnly = false;
            txtStockReplishmentNewItemSparesCategory.ReadOnly = false;
            txtStockReplishmentNewItemPrice.ReadOnly = false;
            comStockReplishmentNewSupplierID.Enabled = true;


            txtStockReplishmentExistingItemQuantity.ReadOnly = true;
            comStockReplishmentExistingItemID.Enabled = false;


            txtReorderID.ReadOnly = true;
            txtReorderDate.ReadOnly = true;
            comReorderStatus.Enabled = false;
            comReorderItemID.Enabled = false;
            txtReorderTotalPrice.ReadOnly = true;
            txtReorderQuantity.ReadOnly = true;
        }

        private void RadEditExistingItem_CheckedChanged(object sender, EventArgs e)
        {
            txtStockReplishmentExistingItemQuantity.ReadOnly = false;
            comStockReplishmentExistingItemID.Enabled = true;



            txtStockReplishmentNewItemID.ReadOnly = true;
            txtStockReplishmentNewItemName.ReadOnly = true;
            txtStockReplishmentNewItemQuantity.ReadOnly = true;
            txtStockReplishmentNewItemRemark.ReadOnly = true;
            txtStockReplishmentNewItemStockRegion.ReadOnly = true;
            txtStockReplishmentNewItemSparesCategory.ReadOnly = true;
            txtStockReplishmentNewItemPrice.ReadOnly = true;
            comStockReplishmentNewSupplierID.Enabled = false;



            txtReorderID.ReadOnly = true;
            txtReorderDate.ReadOnly = true;
            comReorderStatus.Enabled = false;
            comReorderItemID.Enabled = false;
            txtReorderTotalPrice.ReadOnly = true;
            txtReorderQuantity.ReadOnly = true;
        }

        private void Btn_StockReplishmentUpdate_Click(object sender, EventArgs e)
        {
            try
            {


                //資料庫位址
                MySqlConnection myConnection = new MySqlConnection("server = remotemysql.com; user=0i34zb2JRd; database = 0i34zb2JRd; port = 3306; password = 1ygqpDmMJv;");


                //開啟資料庫
                myConnection.Open();


                int a = int.Parse(txtStockReplishmentExistingItemQuantity.Text);
                string b = comStockReplishmentExistingItemID.Text;


                IQueryable<item> result = ef.item.Where(x => x.ItemID == b);

                foreach (item em in result)
                {
                    int p = em.Quantity;

                    a += p;
                }
                ef.SaveChanges();



                string sql = "UPDATE item SET Quantity= '" + a + "' WHERE ItemID='" + b + "'";
                MySqlCommand ppp = new MySqlCommand(sql, myConnection);
                ppp.ExecuteNonQuery();




                myConnection.Close();

                MessageBox.Show("Update is successful");

                this.dataGridView1.DataSource = null;
                this.dataGridView1.Rows.Clear();


                using (var classicContext = new Entities())
                {

                    var items = (from list in classicContext.item
                                 select list);    // select * from employees

                    foreach (var item1 in items.ToList())
                    {
                        dataGridView1.Rows.Add(item1.ItemID, item1.ItemName, item1.Quantity, item1.Remarks, item1.StockRegion, item1.SparesCategory, item1.Price, item1.SupplierID);
                    }

                }
            }
            catch
            {
                MessageBox.Show("Please ensure that the value is entered in corrent format");
            } 
        }

        private void BtnReorderSubmit_Click(object sender, EventArgs e)
        {
            try
            {

                //資料庫位址
                MySqlConnection myConnection = new MySqlConnection("server = remotemysql.com; user=0i34zb2JRd; database = 0i34zb2JRd; port = 3306; password = 1ygqpDmMJv;");


                //開啟資料庫
                myConnection.Open();



                //新增一筆資料
                MySqlCommand cmd = new MySqlCommand();
                cmd.Connection = myConnection;



                string a = comReorderItemID.Text;
                string b = comReorderStatus.Text;



                string timeStr = txtReorderDate.Text;
                DateTime dt = new DateTime();
                DateTime.TryParse(timeStr, out dt);


                cmd.CommandText = "INSERT INTO reorder VALUES(@1,@2,@3,@4,@5,@6)";
                cmd.Parameters.AddWithValue("@1", txtReorderID.Text);
                cmd.Parameters.AddWithValue("@2", b);
                cmd.Parameters.AddWithValue("@3", txtReorderTotalPrice.Text);
                cmd.Parameters.AddWithValue("@4", dt.ToString("yyyy-MM-dd HH:mm:ss"));
                cmd.Parameters.AddWithValue("@5", a);
                cmd.Parameters.AddWithValue("@6", txtReorderQuantity.Text);


                cmd.ExecuteNonQuery();

                myConnection.Close();
                MessageBox.Show("Insert is successful");
            }
            catch
            {
                MessageBox.Show("Please ensure that the value is entered in corrent format");
            }

            this.dataGridView2.DataSource = null;
            this.dataGridView2.Rows.Clear();


            using (var classicContext = new Entities())
            {
                var reorders = (from list in classicContext.reorder
                                select list);    // select * from employees



                foreach (var reorder1 in reorders.ToList())
                {
                    dataGridView2.Rows.Add(reorder1.ReorderID, reorder1.Status, reorder1.TotalPrice, reorder1.Date, reorder1.itemID, reorder1.quantity);

                }
            }
        }

        private void BtnSearchReorder_Click(object sender, EventArgs e)
        {
            try
            {

                if (textBox3.Text == "")
                {
                    throw new FormatException();
                }

                using (var classContext = new Entities())
                { //keyword search
                    dataGridView2.Rows.Clear();
                    string keyword = textBox3.Text;
                    var resultSet = from list in classContext.reorder
                                    where list.ReorderID.Contains(keyword)
                                    select list;
                    this.dataGridView2.DataSource = null;
                    this.dataGridView2.Rows.Clear();
                    foreach (var reorder1 in resultSet.ToList())
                    {
                        dataGridView2.Rows.Add(reorder1.ReorderID, reorder1.Status, reorder1.TotalPrice, reorder1.Date, reorder1.itemID, reorder1.quantity);


                    }


                }
            }
            catch (FormatException e1)
            {
                MessageBox.Show("Please ensure that the value is entered in corrent format");
            }
        }

        private void BtnSearchItem_Click(object sender, EventArgs e)
        {

            try
            {
                if (txt_OrderIDChecking.Text == "")
                {
                    throw new FormatException();
                }



                using (var classContext = new Entities())
                { //keyword search
                    dataGridView1.Rows.Clear();
                    string keyword = txt_OrderIDChecking.Text;
                    var resultSet = from list in classContext.item
                                    where list.ItemID.Contains(keyword)
                                    select list;
                    this.dataGridView1.DataSource = null;
                    this.dataGridView1.Rows.Clear();
                    foreach (var item1 in resultSet.ToList())
                    {
                        dataGridView1.Rows.Add(item1.ItemID, item1.ItemName, item1.Quantity, item1.Remarks, item1.StockRegion, item1.SparesCategory, item1.Price, item1.SupplierID);


                    }


                }
            }
            catch (FormatException e1)
            {
                MessageBox.Show("Please ensure that the value is entered in corrent format");
            }
        }
    }
}