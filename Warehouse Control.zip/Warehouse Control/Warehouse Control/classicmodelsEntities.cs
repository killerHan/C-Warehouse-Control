﻿using System;

namespace Warehouse_Control
{
    internal class classicmodelsEntities : IDisposable
    {
        internal readonly object employees;
        internal readonly object lastName;
        internal object customerID;
        internal object employee;

        public void Dispose()
        {
            throw new NotImplementedException();
        }
    }
}