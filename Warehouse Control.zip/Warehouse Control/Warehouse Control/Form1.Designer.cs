﻿namespace Warehouse_Control
{
    partial class ItemID_list
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.RadEditReorder = new System.Windows.Forms.RadioButton();
            this.btnSearchReorder = new System.Windows.Forms.Button();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.label20 = new System.Windows.Forms.Label();
            this.groupBox5 = new System.Windows.Forms.GroupBox();
            this.comReorderStatus = new System.Windows.Forms.ComboBox();
            this.comReorderItemID = new System.Windows.Forms.ComboBox();
            this.btnReorderSubmit = new System.Windows.Forms.Button();
            this.txtReorderDate = new System.Windows.Forms.TextBox();
            this.txtReorderQuantity = new System.Windows.Forms.TextBox();
            this.txtReorderTotalPrice = new System.Windows.Forms.TextBox();
            this.label19 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.txtReorderID = new System.Windows.Forms.TextBox();
            this.label14 = new System.Windows.Forms.Label();
            this.radEditNewItem = new System.Windows.Forms.RadioButton();
            this.lblReorderID = new System.Windows.Forms.Label();
            this.dataGridView2 = new System.Windows.Forms.DataGridView();
            this.radEditExistingItem = new System.Windows.Forms.RadioButton();
            this.btnSearchItem = new System.Windows.Forms.Button();
            this.txt_OrderIDChecking = new System.Windows.Forms.TextBox();
            this.lblItemID = new System.Windows.Forms.Label();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.txtItemID = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ItemName = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.txtQuantity = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Remarks = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.txtStockRegion = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.txtSparesCategory = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.txtPrice = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.txtSupplierID = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.btn_StockReplishmentUpdate = new System.Windows.Forms.Button();
            this.comStockReplishmentExistingItemID = new System.Windows.Forms.ComboBox();
            this.txtStockReplishmentExistingItemQuantity = new System.Windows.Forms.TextBox();
            this.label11 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.comStockReplishmentNewSupplierID = new System.Windows.Forms.ComboBox();
            this.txtStockReplishmentNewItemPrice = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.txtStockReplishmentNewItemRemark = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.txtStockReplishmentNewItemQuantity = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.btn_StockReplishment = new System.Windows.Forms.Button();
            this.label8 = new System.Windows.Forms.Label();
            this.txtStockReplishmentNewItemStockRegion = new System.Windows.Forms.TextBox();
            this.txtStockReplishmentNewItemSparesCategory = new System.Windows.Forms.TextBox();
            this.txtStockReplishmentNewItemID = new System.Windows.Forms.TextBox();
            this.txtStockReplishmentNewItemName = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.ReorderID = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Status = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.TotalPrice = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Date = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.itemID = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.quantity = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.groupBox1.SuspendLayout();
            this.groupBox5.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.groupBox3.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.RadEditReorder);
            this.groupBox1.Controls.Add(this.btnSearchReorder);
            this.groupBox1.Controls.Add(this.textBox3);
            this.groupBox1.Controls.Add(this.label20);
            this.groupBox1.Controls.Add(this.groupBox5);
            this.groupBox1.Controls.Add(this.radEditNewItem);
            this.groupBox1.Controls.Add(this.lblReorderID);
            this.groupBox1.Controls.Add(this.dataGridView2);
            this.groupBox1.Controls.Add(this.radEditExistingItem);
            this.groupBox1.Controls.Add(this.btnSearchItem);
            this.groupBox1.Controls.Add(this.txt_OrderIDChecking);
            this.groupBox1.Controls.Add(this.lblItemID);
            this.groupBox1.Controls.Add(this.dataGridView1);
            this.groupBox1.Location = new System.Drawing.Point(27, 54);
            this.groupBox1.Margin = new System.Windows.Forms.Padding(4);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Padding = new System.Windows.Forms.Padding(4);
            this.groupBox1.Size = new System.Drawing.Size(1030, 662);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Warehouse Information";
            // 
            // RadEditReorder
            // 
            this.RadEditReorder.AutoSize = true;
            this.RadEditReorder.Font = new System.Drawing.Font("PMingLiU", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.RadEditReorder.Location = new System.Drawing.Point(655, 55);
            this.RadEditReorder.Name = "RadEditReorder";
            this.RadEditReorder.Size = new System.Drawing.Size(223, 32);
            this.RadEditReorder.TabIndex = 67;
            this.RadEditReorder.TabStop = true;
            this.RadEditReorder.Text = "Edit for Reorder";
            this.RadEditReorder.UseVisualStyleBackColor = true;
            this.RadEditReorder.CheckedChanged += new System.EventHandler(this.RadEditReorder_CheckedChanged);
            // 
            // btnSearchReorder
            // 
            this.btnSearchReorder.Location = new System.Drawing.Point(360, 116);
            this.btnSearchReorder.Name = "btnSearchReorder";
            this.btnSearchReorder.Size = new System.Drawing.Size(132, 41);
            this.btnSearchReorder.TabIndex = 63;
            this.btnSearchReorder.Text = "Search";
            this.btnSearchReorder.UseVisualStyleBackColor = true;
            this.btnSearchReorder.Click += new System.EventHandler(this.BtnSearchReorder_Click);
            // 
            // textBox3
            // 
            this.textBox3.BackColor = System.Drawing.Color.WhiteSmoke;
            this.textBox3.Location = new System.Drawing.Point(167, 123);
            this.textBox3.Multiline = true;
            this.textBox3.Name = "textBox3";
            this.textBox3.Size = new System.Drawing.Size(155, 28);
            this.textBox3.TabIndex = 62;
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Font = new System.Drawing.Font("Microsoft YaHei", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label20.Location = new System.Drawing.Point(598, 15);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(394, 37);
            this.label20.TabIndex = 66;
            this.label20.Text = "Choice for Edit stock mode";
            // 
            // groupBox5
            // 
            this.groupBox5.Controls.Add(this.comReorderStatus);
            this.groupBox5.Controls.Add(this.comReorderItemID);
            this.groupBox5.Controls.Add(this.btnReorderSubmit);
            this.groupBox5.Controls.Add(this.txtReorderDate);
            this.groupBox5.Controls.Add(this.txtReorderQuantity);
            this.groupBox5.Controls.Add(this.txtReorderTotalPrice);
            this.groupBox5.Controls.Add(this.label19);
            this.groupBox5.Controls.Add(this.label15);
            this.groupBox5.Controls.Add(this.label18);
            this.groupBox5.Controls.Add(this.label16);
            this.groupBox5.Controls.Add(this.label17);
            this.groupBox5.Controls.Add(this.txtReorderID);
            this.groupBox5.Controls.Add(this.label14);
            this.groupBox5.Location = new System.Drawing.Point(25, 495);
            this.groupBox5.Name = "groupBox5";
            this.groupBox5.Size = new System.Drawing.Size(980, 159);
            this.groupBox5.TabIndex = 60;
            this.groupBox5.TabStop = false;
            this.groupBox5.Text = "Reorder for goods";
            // 
            // comReorderStatus
            // 
            this.comReorderStatus.FormattingEnabled = true;
            this.comReorderStatus.Location = new System.Drawing.Point(142, 69);
            this.comReorderStatus.Name = "comReorderStatus";
            this.comReorderStatus.Size = new System.Drawing.Size(155, 28);
            this.comReorderStatus.TabIndex = 70;
            // 
            // comReorderItemID
            // 
            this.comReorderItemID.FormattingEnabled = true;
            this.comReorderItemID.Location = new System.Drawing.Point(474, 69);
            this.comReorderItemID.Name = "comReorderItemID";
            this.comReorderItemID.Size = new System.Drawing.Size(155, 28);
            this.comReorderItemID.TabIndex = 58;
            // 
            // btnReorderSubmit
            // 
            this.btnReorderSubmit.Location = new System.Drawing.Point(694, 65);
            this.btnReorderSubmit.Name = "btnReorderSubmit";
            this.btnReorderSubmit.Size = new System.Drawing.Size(182, 47);
            this.btnReorderSubmit.TabIndex = 58;
            this.btnReorderSubmit.Text = "Submit";
            this.btnReorderSubmit.UseVisualStyleBackColor = true;
            this.btnReorderSubmit.Click += new System.EventHandler(this.BtnReorderSubmit_Click);
            // 
            // txtReorderDate
            // 
            this.txtReorderDate.Location = new System.Drawing.Point(474, 29);
            this.txtReorderDate.Multiline = true;
            this.txtReorderDate.Name = "txtReorderDate";
            this.txtReorderDate.Size = new System.Drawing.Size(155, 27);
            this.txtReorderDate.TabIndex = 68;
            // 
            // txtReorderQuantity
            // 
            this.txtReorderQuantity.Location = new System.Drawing.Point(474, 111);
            this.txtReorderQuantity.Multiline = true;
            this.txtReorderQuantity.Name = "txtReorderQuantity";
            this.txtReorderQuantity.Size = new System.Drawing.Size(155, 27);
            this.txtReorderQuantity.TabIndex = 66;
            // 
            // txtReorderTotalPrice
            // 
            this.txtReorderTotalPrice.Location = new System.Drawing.Point(142, 113);
            this.txtReorderTotalPrice.Multiline = true;
            this.txtReorderTotalPrice.Name = "txtReorderTotalPrice";
            this.txtReorderTotalPrice.Size = new System.Drawing.Size(155, 27);
            this.txtReorderTotalPrice.TabIndex = 65;
            // 
            // label19
            // 
            this.label19.Location = new System.Drawing.Point(36, 69);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(138, 25);
            this.label19.TabIndex = 64;
            this.label19.Text = "Status";
            // 
            // label15
            // 
            this.label15.Location = new System.Drawing.Point(388, 70);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(138, 25);
            this.label15.TabIndex = 60;
            this.label15.Text = "itemID";
            // 
            // label18
            // 
            this.label18.Location = new System.Drawing.Point(36, 113);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(138, 25);
            this.label18.TabIndex = 63;
            this.label18.Text = "TotalPrice";
            // 
            // label16
            // 
            this.label16.Location = new System.Drawing.Point(388, 31);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(138, 25);
            this.label16.TabIndex = 61;
            this.label16.Text = "Date";
            // 
            // label17
            // 
            this.label17.Location = new System.Drawing.Point(388, 114);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(138, 25);
            this.label17.TabIndex = 62;
            this.label17.Text = "quantity";
            // 
            // txtReorderID
            // 
            this.txtReorderID.Location = new System.Drawing.Point(142, 30);
            this.txtReorderID.Multiline = true;
            this.txtReorderID.Name = "txtReorderID";
            this.txtReorderID.Size = new System.Drawing.Size(155, 27);
            this.txtReorderID.TabIndex = 59;
            // 
            // label14
            // 
            this.label14.Location = new System.Drawing.Point(36, 33);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(138, 25);
            this.label14.TabIndex = 58;
            this.label14.Text = "ReorderID";
            // 
            // radEditNewItem
            // 
            this.radEditNewItem.AutoSize = true;
            this.radEditNewItem.Font = new System.Drawing.Font("PMingLiU", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.radEditNewItem.Location = new System.Drawing.Point(652, 102);
            this.radEditNewItem.Name = "radEditNewItem";
            this.radEditNewItem.Size = new System.Drawing.Size(235, 32);
            this.radEditNewItem.TabIndex = 65;
            this.radEditNewItem.TabStop = true;
            this.radEditNewItem.Text = "Edit for new item";
            this.radEditNewItem.UseVisualStyleBackColor = true;
            this.radEditNewItem.CheckedChanged += new System.EventHandler(this.RadEditNewItem_CheckedChanged);
            // 
            // lblReorderID
            // 
            this.lblReorderID.Font = new System.Drawing.Font("PMingLiU", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.lblReorderID.Location = new System.Drawing.Point(21, 124);
            this.lblReorderID.Name = "lblReorderID";
            this.lblReorderID.Size = new System.Drawing.Size(148, 25);
            this.lblReorderID.TabIndex = 61;
            this.lblReorderID.Text = "Reorder ID";
            // 
            // dataGridView2
            // 
            this.dataGridView2.BackgroundColor = System.Drawing.Color.White;
            this.dataGridView2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView2.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.ReorderID,
            this.Status,
            this.TotalPrice,
            this.Date,
            this.itemID,
            this.quantity});
            this.dataGridView2.Location = new System.Drawing.Point(11, 345);
            this.dataGridView2.Name = "dataGridView2";
            this.dataGridView2.RowHeadersWidth = 51;
            this.dataGridView2.RowTemplate.Height = 27;
            this.dataGridView2.Size = new System.Drawing.Size(994, 144);
            this.dataGridView2.TabIndex = 54;
            // 
            // radEditExistingItem
            // 
            this.radEditExistingItem.AutoSize = true;
            this.radEditExistingItem.Font = new System.Drawing.Font("PMingLiU", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.radEditExistingItem.Location = new System.Drawing.Point(652, 147);
            this.radEditExistingItem.Name = "radEditExistingItem";
            this.radEditExistingItem.Size = new System.Drawing.Size(278, 32);
            this.radEditExistingItem.TabIndex = 64;
            this.radEditExistingItem.TabStop = true;
            this.radEditExistingItem.Text = "Edit for existing item";
            this.radEditExistingItem.UseVisualStyleBackColor = true;
            this.radEditExistingItem.CheckedChanged += new System.EventHandler(this.RadEditExistingItem_CheckedChanged);
            // 
            // btnSearchItem
            // 
            this.btnSearchItem.Location = new System.Drawing.Point(360, 42);
            this.btnSearchItem.Name = "btnSearchItem";
            this.btnSearchItem.Size = new System.Drawing.Size(132, 41);
            this.btnSearchItem.TabIndex = 52;
            this.btnSearchItem.Text = "Search";
            this.btnSearchItem.UseVisualStyleBackColor = true;
            this.btnSearchItem.Click += new System.EventHandler(this.BtnSearchItem_Click);
            // 
            // txt_OrderIDChecking
            // 
            this.txt_OrderIDChecking.BackColor = System.Drawing.Color.WhiteSmoke;
            this.txt_OrderIDChecking.Location = new System.Drawing.Point(167, 49);
            this.txt_OrderIDChecking.Multiline = true;
            this.txt_OrderIDChecking.Name = "txt_OrderIDChecking";
            this.txt_OrderIDChecking.Size = new System.Drawing.Size(155, 33);
            this.txt_OrderIDChecking.TabIndex = 51;
            // 
            // lblItemID
            // 
            this.lblItemID.Font = new System.Drawing.Font("PMingLiU", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.lblItemID.Location = new System.Drawing.Point(21, 55);
            this.lblItemID.Name = "lblItemID";
            this.lblItemID.Size = new System.Drawing.Size(148, 25);
            this.lblItemID.TabIndex = 50;
            this.lblItemID.Text = "Item ID";
            // 
            // dataGridView1
            // 
            this.dataGridView1.BackgroundColor = System.Drawing.Color.White;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.txtItemID,
            this.ItemName,
            this.txtQuantity,
            this.Remarks,
            this.txtStockRegion,
            this.txtSparesCategory,
            this.txtPrice,
            this.txtSupplierID});
            this.dataGridView1.Location = new System.Drawing.Point(11, 181);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.RowHeadersWidth = 51;
            this.dataGridView1.RowTemplate.Height = 27;
            this.dataGridView1.Size = new System.Drawing.Size(994, 147);
            this.dataGridView1.TabIndex = 48;
            // 
            // txtItemID
            // 
            this.txtItemID.HeaderText = "ItemID";
            this.txtItemID.MinimumWidth = 6;
            this.txtItemID.Name = "txtItemID";
            this.txtItemID.ReadOnly = true;
            this.txtItemID.Width = 125;
            // 
            // ItemName
            // 
            this.ItemName.HeaderText = "ItemName";
            this.ItemName.MinimumWidth = 6;
            this.ItemName.Name = "ItemName";
            this.ItemName.ReadOnly = true;
            this.ItemName.Width = 125;
            // 
            // txtQuantity
            // 
            this.txtQuantity.HeaderText = "Quantity";
            this.txtQuantity.MinimumWidth = 6;
            this.txtQuantity.Name = "txtQuantity";
            this.txtQuantity.ReadOnly = true;
            this.txtQuantity.Width = 125;
            // 
            // Remarks
            // 
            this.Remarks.HeaderText = "Remarks";
            this.Remarks.MinimumWidth = 6;
            this.Remarks.Name = "Remarks";
            this.Remarks.ReadOnly = true;
            this.Remarks.Width = 110;
            // 
            // txtStockRegion
            // 
            this.txtStockRegion.HeaderText = "StockRegion";
            this.txtStockRegion.MinimumWidth = 6;
            this.txtStockRegion.Name = "txtStockRegion";
            this.txtStockRegion.ReadOnly = true;
            this.txtStockRegion.Width = 125;
            // 
            // txtSparesCategory
            // 
            this.txtSparesCategory.HeaderText = "SparesCategory";
            this.txtSparesCategory.MinimumWidth = 6;
            this.txtSparesCategory.Name = "txtSparesCategory";
            this.txtSparesCategory.ReadOnly = true;
            this.txtSparesCategory.Width = 150;
            // 
            // txtPrice
            // 
            this.txtPrice.HeaderText = "Price";
            this.txtPrice.MinimumWidth = 6;
            this.txtPrice.Name = "txtPrice";
            this.txtPrice.ReadOnly = true;
            this.txtPrice.Width = 125;
            // 
            // txtSupplierID
            // 
            this.txtSupplierID.HeaderText = "SupplierID";
            this.txtSupplierID.MinimumWidth = 6;
            this.txtSupplierID.Name = "txtSupplierID";
            this.txtSupplierID.ReadOnly = true;
            this.txtSupplierID.Width = 125;
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.btn_StockReplishmentUpdate);
            this.groupBox3.Controls.Add(this.comStockReplishmentExistingItemID);
            this.groupBox3.Controls.Add(this.txtStockReplishmentExistingItemQuantity);
            this.groupBox3.Controls.Add(this.label11);
            this.groupBox3.Controls.Add(this.label12);
            this.groupBox3.Location = new System.Drawing.Point(1064, 510);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(334, 198);
            this.groupBox3.TabIndex = 56;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Stock Replenishment of Item Quantity";
            // 
            // btn_StockReplishmentUpdate
            // 
            this.btn_StockReplishmentUpdate.Location = new System.Drawing.Point(147, 142);
            this.btn_StockReplishmentUpdate.Name = "btn_StockReplishmentUpdate";
            this.btn_StockReplishmentUpdate.Size = new System.Drawing.Size(155, 47);
            this.btn_StockReplishmentUpdate.TabIndex = 57;
            this.btn_StockReplishmentUpdate.Text = "Update";
            this.btn_StockReplishmentUpdate.UseVisualStyleBackColor = true;
            this.btn_StockReplishmentUpdate.Click += new System.EventHandler(this.Btn_StockReplishmentUpdate_Click);
            // 
            // comStockReplishmentExistingItemID
            // 
            this.comStockReplishmentExistingItemID.Enabled = false;
            this.comStockReplishmentExistingItemID.FormattingEnabled = true;
            this.comStockReplishmentExistingItemID.Location = new System.Drawing.Point(147, 56);
            this.comStockReplishmentExistingItemID.Name = "comStockReplishmentExistingItemID";
            this.comStockReplishmentExistingItemID.Size = new System.Drawing.Size(155, 28);
            this.comStockReplishmentExistingItemID.TabIndex = 56;
            // 
            // txtStockReplishmentExistingItemQuantity
            // 
            this.txtStockReplishmentExistingItemQuantity.Location = new System.Drawing.Point(147, 104);
            this.txtStockReplishmentExistingItemQuantity.Multiline = true;
            this.txtStockReplishmentExistingItemQuantity.Name = "txtStockReplishmentExistingItemQuantity";
            this.txtStockReplishmentExistingItemQuantity.ReadOnly = true;
            this.txtStockReplishmentExistingItemQuantity.Size = new System.Drawing.Size(155, 27);
            this.txtStockReplishmentExistingItemQuantity.TabIndex = 31;
            // 
            // label11
            // 
            this.label11.Location = new System.Drawing.Point(19, 59);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(138, 25);
            this.label11.TabIndex = 31;
            this.label11.Text = "Item ID";
            // 
            // label12
            // 
            this.label12.Location = new System.Drawing.Point(19, 104);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(138, 25);
            this.label12.TabIndex = 57;
            this.label12.Text = "Quantity";
            // 
            // label1
            // 
            this.label1.Font = new System.Drawing.Font("PMingLiU", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label1.Location = new System.Drawing.Point(22, 12);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(327, 38);
            this.label1.TabIndex = 0;
            this.label1.Text = "Warehouse Management";
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.comStockReplishmentNewSupplierID);
            this.groupBox2.Controls.Add(this.txtStockReplishmentNewItemPrice);
            this.groupBox2.Controls.Add(this.label10);
            this.groupBox2.Controls.Add(this.txtStockReplishmentNewItemRemark);
            this.groupBox2.Controls.Add(this.label3);
            this.groupBox2.Controls.Add(this.txtStockReplishmentNewItemQuantity);
            this.groupBox2.Controls.Add(this.label2);
            this.groupBox2.Controls.Add(this.btn_StockReplishment);
            this.groupBox2.Controls.Add(this.label8);
            this.groupBox2.Controls.Add(this.txtStockReplishmentNewItemStockRegion);
            this.groupBox2.Controls.Add(this.txtStockReplishmentNewItemSparesCategory);
            this.groupBox2.Controls.Add(this.txtStockReplishmentNewItemID);
            this.groupBox2.Controls.Add(this.txtStockReplishmentNewItemName);
            this.groupBox2.Controls.Add(this.label6);
            this.groupBox2.Controls.Add(this.label7);
            this.groupBox2.Controls.Add(this.label5);
            this.groupBox2.Controls.Add(this.label4);
            this.groupBox2.Location = new System.Drawing.Point(1064, 68);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(334, 426);
            this.groupBox2.TabIndex = 3;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Stock Replenishment of New Item";
            // 
            // comStockReplishmentNewSupplierID
            // 
            this.comStockReplishmentNewSupplierID.Enabled = false;
            this.comStockReplishmentNewSupplierID.FormattingEnabled = true;
            this.comStockReplishmentNewSupplierID.Location = new System.Drawing.Point(147, 299);
            this.comStockReplishmentNewSupplierID.Name = "comStockReplishmentNewSupplierID";
            this.comStockReplishmentNewSupplierID.Size = new System.Drawing.Size(155, 28);
            this.comStockReplishmentNewSupplierID.TabIndex = 58;
            // 
            // txtStockReplishmentNewItemPrice
            // 
            this.txtStockReplishmentNewItemPrice.Location = new System.Drawing.Point(147, 262);
            this.txtStockReplishmentNewItemPrice.Multiline = true;
            this.txtStockReplishmentNewItemPrice.Name = "txtStockReplishmentNewItemPrice";
            this.txtStockReplishmentNewItemPrice.ReadOnly = true;
            this.txtStockReplishmentNewItemPrice.Size = new System.Drawing.Size(155, 27);
            this.txtStockReplishmentNewItemPrice.TabIndex = 30;
            // 
            // label10
            // 
            this.label10.Location = new System.Drawing.Point(23, 262);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(138, 25);
            this.label10.TabIndex = 29;
            this.label10.Text = "Price";
            // 
            // txtStockReplishmentNewItemRemark
            // 
            this.txtStockReplishmentNewItemRemark.Location = new System.Drawing.Point(147, 142);
            this.txtStockReplishmentNewItemRemark.Multiline = true;
            this.txtStockReplishmentNewItemRemark.Name = "txtStockReplishmentNewItemRemark";
            this.txtStockReplishmentNewItemRemark.ReadOnly = true;
            this.txtStockReplishmentNewItemRemark.Size = new System.Drawing.Size(155, 27);
            this.txtStockReplishmentNewItemRemark.TabIndex = 28;
            // 
            // label3
            // 
            this.label3.Location = new System.Drawing.Point(23, 142);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(138, 25);
            this.label3.TabIndex = 27;
            this.label3.Text = "Remarks";
            // 
            // txtStockReplishmentNewItemQuantity
            // 
            this.txtStockReplishmentNewItemQuantity.Location = new System.Drawing.Point(147, 102);
            this.txtStockReplishmentNewItemQuantity.Multiline = true;
            this.txtStockReplishmentNewItemQuantity.Name = "txtStockReplishmentNewItemQuantity";
            this.txtStockReplishmentNewItemQuantity.ReadOnly = true;
            this.txtStockReplishmentNewItemQuantity.Size = new System.Drawing.Size(155, 27);
            this.txtStockReplishmentNewItemQuantity.TabIndex = 26;
            // 
            // label2
            // 
            this.label2.Location = new System.Drawing.Point(23, 102);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(197, 49);
            this.label2.TabIndex = 25;
            this.label2.Text = "Quantity";
            // 
            // btn_StockReplishment
            // 
            this.btn_StockReplishment.Location = new System.Drawing.Point(147, 354);
            this.btn_StockReplishment.Name = "btn_StockReplishment";
            this.btn_StockReplishment.Size = new System.Drawing.Size(144, 46);
            this.btn_StockReplishment.TabIndex = 24;
            this.btn_StockReplishment.Text = "Input";
            this.btn_StockReplishment.UseVisualStyleBackColor = true;
            this.btn_StockReplishment.Click += new System.EventHandler(this.btn_StockReplishment_Click);
            // 
            // label8
            // 
            this.label8.Location = new System.Drawing.Point(23, 302);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(161, 25);
            this.label8.TabIndex = 14;
            this.label8.Text = "SupplierID";
            // 
            // txtStockReplishmentNewItemStockRegion
            // 
            this.txtStockReplishmentNewItemStockRegion.Location = new System.Drawing.Point(147, 180);
            this.txtStockReplishmentNewItemStockRegion.Multiline = true;
            this.txtStockReplishmentNewItemStockRegion.Name = "txtStockReplishmentNewItemStockRegion";
            this.txtStockReplishmentNewItemStockRegion.ReadOnly = true;
            this.txtStockReplishmentNewItemStockRegion.Size = new System.Drawing.Size(155, 27);
            this.txtStockReplishmentNewItemStockRegion.TabIndex = 12;
            // 
            // txtStockReplishmentNewItemSparesCategory
            // 
            this.txtStockReplishmentNewItemSparesCategory.Location = new System.Drawing.Point(163, 219);
            this.txtStockReplishmentNewItemSparesCategory.Multiline = true;
            this.txtStockReplishmentNewItemSparesCategory.Name = "txtStockReplishmentNewItemSparesCategory";
            this.txtStockReplishmentNewItemSparesCategory.ReadOnly = true;
            this.txtStockReplishmentNewItemSparesCategory.Size = new System.Drawing.Size(155, 27);
            this.txtStockReplishmentNewItemSparesCategory.TabIndex = 9;
            // 
            // txtStockReplishmentNewItemID
            // 
            this.txtStockReplishmentNewItemID.Location = new System.Drawing.Point(147, 27);
            this.txtStockReplishmentNewItemID.Multiline = true;
            this.txtStockReplishmentNewItemID.Name = "txtStockReplishmentNewItemID";
            this.txtStockReplishmentNewItemID.ReadOnly = true;
            this.txtStockReplishmentNewItemID.Size = new System.Drawing.Size(155, 27);
            this.txtStockReplishmentNewItemID.TabIndex = 8;
            // 
            // txtStockReplishmentNewItemName
            // 
            this.txtStockReplishmentNewItemName.Location = new System.Drawing.Point(147, 63);
            this.txtStockReplishmentNewItemName.Multiline = true;
            this.txtStockReplishmentNewItemName.Name = "txtStockReplishmentNewItemName";
            this.txtStockReplishmentNewItemName.ReadOnly = true;
            this.txtStockReplishmentNewItemName.Size = new System.Drawing.Size(155, 27);
            this.txtStockReplishmentNewItemName.TabIndex = 5;
            // 
            // label6
            // 
            this.label6.Location = new System.Drawing.Point(19, 219);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(138, 25);
            this.label6.TabIndex = 11;
            this.label6.Text = "SparesCategory";
            // 
            // label7
            // 
            this.label7.Location = new System.Drawing.Point(23, 66);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(138, 25);
            this.label7.TabIndex = 10;
            this.label7.Text = "Item Name";
            // 
            // label5
            // 
            this.label5.Location = new System.Drawing.Point(23, 27);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(138, 25);
            this.label5.TabIndex = 6;
            this.label5.Text = "Item ID";
            // 
            // label4
            // 
            this.label4.Location = new System.Drawing.Point(23, 180);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(138, 25);
            this.label4.TabIndex = 7;
            this.label4.Text = "StockRegion";
            // 
            // ReorderID
            // 
            this.ReorderID.HeaderText = "ReorderID";
            this.ReorderID.MinimumWidth = 6;
            this.ReorderID.Name = "ReorderID";
            this.ReorderID.Width = 170;
            // 
            // Status
            // 
            this.Status.HeaderText = "Status";
            this.Status.MinimumWidth = 6;
            this.Status.Name = "Status";
            this.Status.Width = 170;
            // 
            // TotalPrice
            // 
            this.TotalPrice.HeaderText = "TotalPrice";
            this.TotalPrice.MinimumWidth = 6;
            this.TotalPrice.Name = "TotalPrice";
            this.TotalPrice.Width = 170;
            // 
            // Date
            // 
            this.Date.HeaderText = "Date";
            this.Date.MinimumWidth = 6;
            this.Date.Name = "Date";
            this.Date.Width = 170;
            // 
            // itemID
            // 
            this.itemID.HeaderText = "itemID";
            this.itemID.MinimumWidth = 6;
            this.itemID.Name = "itemID";
            this.itemID.Width = 170;
            // 
            // quantity
            // 
            this.quantity.HeaderText = "quantity";
            this.quantity.MinimumWidth = 6;
            this.quantity.Name = "quantity";
            this.quantity.Width = 120;
            // 
            // ItemID_list
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(12F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1424, 715);
            this.Controls.Add(this.groupBox3);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.groupBox1);
            this.Font = new System.Drawing.Font("PMingLiU", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "ItemID_list";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.ItemID_list_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox5.ResumeLayout(false);
            this.groupBox5.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox txtStockReplishmentNewItemStockRegion;
        private System.Windows.Forms.TextBox txtStockReplishmentNewItemSparesCategory;
        private System.Windows.Forms.TextBox txtStockReplishmentNewItemID;
        private System.Windows.Forms.TextBox txtStockReplishmentNewItemName;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Button btn_StockReplishment;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button btnSearchItem;
        private System.Windows.Forms.TextBox txt_OrderIDChecking;
        private System.Windows.Forms.Label lblItemID;
        private System.Windows.Forms.TextBox txtStockReplishmentNewItemRemark;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txtStockReplishmentNewItemQuantity;
        private System.Windows.Forms.TextBox txtStockReplishmentNewItemPrice;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.TextBox txtStockReplishmentExistingItemQuantity;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.ComboBox comStockReplishmentExistingItemID;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Button btn_StockReplishmentUpdate;
        private System.Windows.Forms.ComboBox comStockReplishmentNewSupplierID;
        private System.Windows.Forms.DataGridView dataGridView2;
        private System.Windows.Forms.GroupBox groupBox5;
        private System.Windows.Forms.Button btnReorderSubmit;
        private System.Windows.Forms.TextBox txtReorderDate;
        private System.Windows.Forms.TextBox txtReorderQuantity;
        private System.Windows.Forms.TextBox txtReorderTotalPrice;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.TextBox txtReorderID;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.ComboBox comReorderItemID;
        private System.Windows.Forms.Button btnSearchReorder;
        private System.Windows.Forms.TextBox textBox3;
        private System.Windows.Forms.Label lblReorderID;
        private System.Windows.Forms.ComboBox comReorderStatus;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.RadioButton radEditNewItem;
        private System.Windows.Forms.RadioButton radEditExistingItem;
        private System.Windows.Forms.DataGridViewTextBoxColumn txtItemID;
        private System.Windows.Forms.DataGridViewTextBoxColumn ItemName;
        private System.Windows.Forms.DataGridViewTextBoxColumn txtQuantity;
        private System.Windows.Forms.DataGridViewTextBoxColumn Remarks;
        private System.Windows.Forms.DataGridViewTextBoxColumn txtStockRegion;
        private System.Windows.Forms.DataGridViewTextBoxColumn txtSparesCategory;
        private System.Windows.Forms.DataGridViewTextBoxColumn txtPrice;
        private System.Windows.Forms.DataGridViewTextBoxColumn txtSupplierID;
        private System.Windows.Forms.RadioButton RadEditReorder;
        private System.Windows.Forms.DataGridViewTextBoxColumn ReorderID;
        private System.Windows.Forms.DataGridViewTextBoxColumn Status;
        private System.Windows.Forms.DataGridViewTextBoxColumn TotalPrice;
        private System.Windows.Forms.DataGridViewTextBoxColumn Date;
        private System.Windows.Forms.DataGridViewTextBoxColumn itemID;
        private System.Windows.Forms.DataGridViewTextBoxColumn quantity;
    }
}

